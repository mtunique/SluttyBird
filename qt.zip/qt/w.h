#ifndef WMT_H
#define WMT_H
qt w;

#endif WMT_H
#ifndef BUG_H
#define BUG_H

int a;
b2Body *body;
b2Body *endedge;
b2World *world;

float32 timeStep;
int32 velocity;
int32 position;


#endif BUG_H
